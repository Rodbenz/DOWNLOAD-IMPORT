import os
os.system("D:\py_importTxt\startup.bat")